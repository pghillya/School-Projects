from django.contrib import admin
from students.models import Studentdetails
from students.models import Coursedetails

# Register your models here.
admin.site.register(Studentdetails)
admin.site.register(Coursedetails)
