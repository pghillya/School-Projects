from django.db import models


# Create your models here.

class Studentdetails(models.Model):
	studentid=models.CharField(max_length=500)
	firstname=models.CharField(max_length=500)
	lastname=models.CharField(max_length=500)
	major=models.CharField(max_length=50)
	classyear=models.CharField(max_length=50)
	GPA=models.CharField(max_length=50)

class Coursedetails(models.Model):
	courseid=models.CharField(max_length=500)
	coursetitle=models.CharField(max_length=500)
	coursename=models.CharField(max_length=500)
	coursesectioncode=models.CharField(max_length=500)
	coursedepartment=models.CharField(max_length=500)
	instructorname=models.CharField(max_length=500)

course_choices=(('3903','3903'),('107349','107349'),('107368','107368'),('107375','107375'),('107378','107378'),('107380','107380'),('107425','107425'),('107451','107451'),('107455','107455'),('107600','107600'),('107602','107602'),('107628','107628'),('107630','107630'),('107672','107672'),
('107703','107703'),('107706','107706'),('107746','107746'),('107761','107761'),('107764','107764'))

student_choices=(('1002','1002'),('1003','1003'),('1004','1004'),('1005','1005'),('1006','1006'),('1007','1007'),('1008','1008'),('1009','1009'),('1010','1010'),('1011','1011'),('1012','1012'),('1013','1013'),('1014','1014'),('1015','1015'),('1016','1016'),('1017','1017'),('1018','1018'),('1019','1019'),('1020','1020'))
class Courseenrollment(models.Model):
	courseid=models.CharField(max_length=700, choices=course_choices)
	totalenrolled=models.CharField(max_length=500)
	studentid=models.CharField(max_length=500, choices=student_choices)
	def __str__(self):
		return self.courseid



