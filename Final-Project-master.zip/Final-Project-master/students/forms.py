from django import forms
from .models import Coursedetails, Studentdetails, Courseenrollment



class CourseEnrollForm(forms.ModelForm):
	class Meta:
		model = Courseenrollment
		fields = ['studentid','courseid']
		courses=forms.ChoiceField(choices=(1002, 1003, 1004))
form = CourseEnrollForm()

