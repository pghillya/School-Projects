from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from students.models import Studentdetails
from students.models import Coursedetails
from .models import Courseenrollment
from django.db import connection
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django_tables2 import SingleTableView
from django.views.generic import ListView, CreateView, UpdateView
from .forms import CourseEnrollForm
from django.db.models.query import QuerySet
import json
from django.db.models import Count
#from .tables import CoursedetailsTable
# Create your views here.



@login_required
def home(request):
	context = {'name':'Peter'}
	return render(request, 'students/home.html', context)

@login_required
def studentdetails(request):
	context = {'name':'Peter'}
	studentdetails=Studentdetails.objects.all()
	paginator= Paginator(studentdetails, 5)
	page= request.GET.get('page')
	studentminiset = paginator.get_page(page)
	return render(request, 'students/studentdetails.html', {'data':studentminiset})
	

@login_required
def coursedetails(request):
	coursedetails=Coursedetails.objects.all()
	paginator= Paginator(coursedetails, 5)
	page= request.GET.get('page')
	courseminiset = paginator.get_page(page)
	return render(request, 'students/coursedetails.html', {'data':courseminiset})


##@login_required
#def courseenrollment(request):
##	courseenrollment=Courseenrollment.objects.all()
	#paginator= Paginator(coursedetails, 5)
	#page= request.GET.get('page')
	#courseminiset = paginator.get_page(page)
	##return render(request, 'students/courseenrollment.html', {'data':courseenrollment})
	#return render(request, 'students/courseenrollment.html'), {'data':courseenrollment})



@login_required
def courseenrollment(request):
	# get the post selected student id input here, save to a variable, then compare to len() in the if statement
	form = CourseEnrollForm(request.POST)
		
	answer=form.data.get('studentid')
	

	if form.is_valid():
		if len(Courseenrollment.objects.filter(studentid=answer))>=3:
			return render(request, 'students/limitreached.html')
		else:

			form.save()
			return HttpResponseRedirect('/students/thanks')

	else:
		form = CourseEnrollForm()
		context={"form":form}
		return render(request, 'students/courseenrollment.html', {'form':form})


def thanks(request):
	return render(request, 'students/thanks.html')

def limitreached(request):
	return render(request, 'students/limitreached.html')

def chart(request):
	categories = list()
	enrolledcourses = Courseenrollment.objects.values('courseid')
	enrolledstudents = Courseenrollment.objects.values('studentid')

	
	chart = {

		'chart':{'type': 'column'},
		'title':{'text': 'Students by Courses'},
		'xAxis':{'categories': enrolledcourses}
}

	dump = json.dumps(chart)
	return render(request, 'students/home.html',{'chart':dump})
