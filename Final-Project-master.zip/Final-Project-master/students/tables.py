import django_tables2 as tables
from .models import Coursedetails

class CoursedetailsTable(tables.Table):
	class Meta:
		model = Coursedetails
		template_name = "django_tables2/bootsrap.html"
		fields = ("name", )
